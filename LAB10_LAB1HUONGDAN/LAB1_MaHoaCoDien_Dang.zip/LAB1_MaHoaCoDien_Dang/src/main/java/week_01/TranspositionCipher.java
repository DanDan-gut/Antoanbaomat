package week_01;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Thuật toán Mã hóa Hoán vị Cột theo thứ tự chỉ số (VD: 2,3,1)
 */
public class TranspositionCipher {

    // Hàm kiểm tra và chuyển đổi khóa chuỗi (VD: "2,3,1") thành mảng số nguyên
    public static int[] parseKey(String keyStr) {
        if (keyStr == null || keyStr.trim().isEmpty()) {
            throw new IllegalArgumentException("Khóa không được để trống.");
        }

        String[] parts = keyStr.trim().split("[,\\s]+");
        int m = parts.length;
        int[] key = new int[m];
        Set<Integer> seen = new HashSet<>();

        for (int i = 0; i < m; i++) {
            try {
                int val = Integer.parseInt(parts[i]);
                if (val < 1 || val > m || seen.contains(val)) {
                    throw new IllegalArgumentException("Khóa phải là hoán vị 1.." + m);
                }
                seen.add(val);
                key[i] = val;
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Khóa phải là hoán vị 1.." + m);
            }
        }
        return key;
    }

    // Mã hóa
    public static String encrypt(String plaintext, String keyStr) {
        int[] key = parseKey(keyStr);
        plaintext = plaintext.replaceAll("\\s+", "");
        if (plaintext.isEmpty()) {
            throw new IllegalArgumentException("Plaintext không được để trống.");
        }

        int numCols = key.length;
        int numRows = (int) Math.ceil((double) plaintext.length() / numCols);

        char[][] grid = new char[numRows][numCols];
        int idx = 0;

        // Điền Plaintext vào ma trận theo hàng
        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numCols; j++) {
                if (idx < plaintext.length()) {
                    grid[i][j] = plaintext.charAt(idx++);
                } else {
                    grid[i][j] = ' '; // Không dùng ký tự thừa 'X'
                }
            }
        }

        StringBuilder ciphertext = new StringBuilder();

        // Đọc theo thứ tự chỉ số trong khóa (chuyển sang chỉ số 0-based: val - 1)
        for (int k : key) {
            int colIdx = k - 1;
            for (int r = 0; r < numRows; r++) {
                if (grid[r][colIdx] != ' ') {
                    ciphertext.append(grid[r][colIdx]);
                }
            }
        }

        return ciphertext.toString();
    }

    // Giải mã
    public static String decrypt(String ciphertext, String keyStr) {
        int[] key = parseKey(keyStr);
        ciphertext = ciphertext.replaceAll("\\s+", "");
        if (ciphertext.isEmpty()) {
            throw new IllegalArgumentException("Ciphertext không được để trống.");
        }

        int numCols = key.length;
        int len = ciphertext.length();
        int numRows = (int) Math.ceil((double) len / numCols);

        // Tính số ký tự trên từng cột
        int baseChars = len / numCols;
        int extraChars = len % numCols;

        int[] colLengths = new int[numCols];
        for (int c = 0; c < numCols; c++) {
            colLengths[c] = baseChars + (c < extraChars ? 1 : 0);
        }

        char[][] grid = new char[numRows][numCols];
        int idx = 0;

        // Điền Ciphertext vào ma trận theo thứ tự cột của khóa
        for (int k : key) {
            int colIdx = k - 1;
            int currentColLen = colLengths[colIdx];
            for (int r = 0; r < currentColLen; r++) {
                if (idx < ciphertext.length()) {
                    grid[r][colIdx] = ciphertext.charAt(idx++);
                }
            }
        }

        StringBuilder plaintext = new StringBuilder();
        // Đọc lại ma trận theo hàng
        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numCols; j++) {
                if (grid[i][j] != '\0') {
                    plaintext.append(grid[i][j]);
                }
            }
        }

        return plaintext.toString();
    }
}