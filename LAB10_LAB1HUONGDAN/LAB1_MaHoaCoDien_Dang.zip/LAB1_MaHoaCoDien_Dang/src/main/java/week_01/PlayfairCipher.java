package week_01;

/**
 * Thuật toán mã hóa Playfair Cipher (Ma trận 5x5)
 */
public class PlayfairCipher {

    // Dựng ma trận 5x5 từ Key
    public static char[][] createMatrix(String key) {
        char[][] matrix = new char[5][5];
        boolean[] used = new boolean[26];
        used['J' - 'A'] = true; // Gộp J thành I

        StringBuilder sb = new StringBuilder();
        key = key.toUpperCase().replaceAll("[^A-Z]", "").replace('J', 'I');

        for (char c : key.toCharArray()) {
            if (!used[c - 'A']) {
                used[c - 'A'] = true;
                sb.append(c);
            }
        }

        for (char c = 'A'; c <= 'Z'; c++) {
            if (!used[c - 'A']) {
                used[c - 'A'] = true;
                sb.append(c);
            }
        }

        int idx = 0;
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                matrix[i][j] = sb.charAt(idx++);
            }
        }
        return matrix;
    }

    // Tạo chuỗi định dạng đẹp hiển thị ma trận 5x5 ra ô Key Matrix
    public static String generateMatrixString(String key) {
        if (key == null || key.trim().isEmpty()) {
            throw new IllegalArgumentException("Khóa Playfair không được để trống.");
        }
        char[][] matrix = createMatrix(key);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                sb.append(matrix[i][j]).append("  ");
            }
            if (i < 4) sb.append("\n");
        }
        return sb.toString();
    }

    private static String formatPlaintext(String text) {
        text = text.toUpperCase().replaceAll("[^A-Z]", "").replace('J', 'I');
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < text.length(); i++) {
            char c1 = text.charAt(i);
            result.append(c1);

            if (i + 1 < text.length()) {
                char c2 = text.charAt(i + 1);
                if (c1 == c2) {
                    result.append('X');
                } else {
                    result.append(c2);
                    i++;
                }
            }
        }

        if (result.length() % 2 != 0) {
            result.append('X');
        }

        return result.toString();
    }

    private static int[] findPosition(char[][] matrix, char c) {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (matrix[i][j] == c) {
                    return new int[]{i, j};
                }
            }
        }
        return null;
    }

    public static String encrypt(String plaintext, String key) {
        if (key == null || key.trim().isEmpty()) {
            throw new IllegalArgumentException("Khóa Playfair không được để trống.");
        }

        char[][] matrix = createMatrix(key);
        String formatted = formatPlaintext(plaintext);
        StringBuilder cipher = new StringBuilder();

        for (int i = 0; i < formatted.length(); i += 2) {
            char c1 = formatted.charAt(i);
            char c2 = formatted.charAt(i + 1);

            int[] pos1 = findPosition(matrix, c1);
            int[] pos2 = findPosition(matrix, c2);

            int r1 = pos1[0], c1_idx = pos1[1];
            int r2 = pos2[0], c2_idx = pos2[1];

            if (r1 == r2) {
                cipher.append(matrix[r1][(c1_idx + 1) % 5]);
                cipher.append(matrix[r2][(c2_idx + 1) % 5]);
            } else if (c1_idx == c2_idx) {
                cipher.append(matrix[(r1 + 1) % 5][c1_idx]);
                cipher.append(matrix[(r2 + 1) % 5][c2_idx]);
            } else {
                cipher.append(matrix[r1][c2_idx]);
                cipher.append(matrix[r2][c1_idx]);
            }
        }
        return cipher.toString();
    }

    public static String decrypt(String ciphertext, String key) {
        if (key == null || key.trim().isEmpty()) {
            throw new IllegalArgumentException("Khóa Playfair không được để trống.");
        }

        char[][] matrix = createMatrix(key);
        ciphertext = ciphertext.toUpperCase().replaceAll("[^A-Z]", "");
        StringBuilder plain = new StringBuilder();

        for (int i = 0; i < ciphertext.length(); i += 2) {
            char c1 = ciphertext.charAt(i);
            char c2 = ciphertext.charAt(i + 1);

            int[] pos1 = findPosition(matrix, c1);
            int[] pos2 = findPosition(matrix, c2);

            int r1 = pos1[0], c1_idx = pos1[1];
            int r2 = pos2[0], c2_idx = pos2[1];

            if (r1 == r2) {
                plain.append(matrix[r1][(c1_idx + 4) % 5]);
                plain.append(matrix[r2][(c2_idx + 4) % 5]);
            } else if (c1_idx == c2_idx) {
                plain.append(matrix[(r1 + 4) % 5][c1_idx]);
                plain.append(matrix[(r2 + 4) % 5][c2_idx]);
            } else {
                plain.append(matrix[r1][c2_idx]);
                plain.append(matrix[r2][c1_idx]);
            }
        }
        return plain.toString();
    }
}