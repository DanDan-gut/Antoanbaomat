package week_01;

/**
 * Thuật toán mã hóa Autokey Cipher (Tự động khóa)
 */
public class AutokeyCipher {

    // Kiểm tra định dạng khóa (chỉ nhận chuỗi chữ cái A-Z)
    public static void validateKey(String key) {
        if (key == null || key.trim().isEmpty() || !key.matches("[a-zA-Z]+")) {
            throw new IllegalArgumentException("Khóa Autokey chỉ gồm A-Z.");
        }
    }

    // Mã hóa Autokey
    public static String encrypt(String plaintext, String key) {
        validateKey(key);

        plaintext = plaintext.toUpperCase().replaceAll("[^A-Z]", "");
        key = key.toUpperCase();

        if (plaintext.isEmpty()) {
            throw new IllegalArgumentException("Plaintext không được để trống.");
        }

        // Chuỗi khóa tự động = Key ban đầu + Plaintext
        String autoKey = key + plaintext;
        StringBuilder ciphertext = new StringBuilder();

        for (int i = 0; i < plaintext.length(); i++) {
            char p = plaintext.charAt(i);
            char k = autoKey.charAt(i);
            // Ci = (Pi + Ki) mod 26
            char c = (char) ((p - 'A' + (k - 'A')) % 26 + 'A');
            ciphertext.append(c);
        }

        return ciphertext.toString();
    }

    // Giải mã Autokey
    public static String decrypt(String ciphertext, String key) {
        validateKey(key);

        ciphertext = ciphertext.toUpperCase().replaceAll("[^A-Z]", "");
        key = key.toUpperCase();

        if (ciphertext.isEmpty()) {
            throw new IllegalArgumentException("Ciphertext không được để trống.");
        }

        StringBuilder plaintext = new StringBuilder();
        StringBuilder currentKey = new StringBuilder(key);

        for (int i = 0; i < ciphertext.length(); i++) {
            char c = ciphertext.charAt(i);
            char k = currentKey.charAt(i);
            // Pi = (Ci - Ki + 26) mod 26
            char p = (char) ((c - 'A' - (k - 'A') + 26) % 26 + 'A');
            plaintext.append(p);
            // Nối ký tự vừa giải mã được vào cuối dãy key để giải mã ký tự tiếp theo
            currentKey.append(p);
        }

        return plaintext.toString();
    }
}