package week_01;

public class RailFenceCipher {

    public static String encrypt(String text, int key) {
        if (key <= 1) {
            throw new IllegalArgumentException("Khóa (số hàng) phải lớn hơn 1.");
        }
        char[][] rail = new char[key][text.length()];
        for (int i = 0; i < key; i++) {
            for (int j = 0; j < text.length(); j++) {
                rail[i][j] = '\n';
            }
        }

        boolean down = false;
        int row = 0, col = 0;

        for (int i = 0; i < text.length(); i++) {
            if (row == 0 || row == key - 1) {
                down = !down;
            }
            rail[row][col++] = text.charAt(i);
            row += down ? 1 : -1;
        }

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < key; i++) {
            for (int j = 0; j < text.length(); j++) {
                if (rail[i][j] != '\n') {
                    result.append(rail[i][j]);
                }
            }
        }
        return result.toString();
    }

    public static String decrypt(String cipher, int key) {
        if (key <= 1) {
            throw new IllegalArgumentException("Khóa (số hàng) phải lớn hơn 1.");
        }
        char[][] rail = new char[key][cipher.length()];
        for (int i = 0; i < key; i++) {
            for (int j = 0; j < cipher.length(); j++) {
                rail[i][j] = '\n';
            }
        }

        boolean down = false;
        int row = 0, col = 0;

        for (int i = 0; i < cipher.length(); i++) {
            if (row == 0) {
                down = true;
            }
            if (row == key - 1) {
                down = false;
            }
            rail[row][col++] = '*';
            row += down ? 1 : -1;
        }

        int index = 0;
        for (int i = 0; i < key; i++) {
            for (int j = 0; j < cipher.length(); j++) {
                if (rail[i][j] == '*' && index < cipher.length()) {
                    rail[i][j] = cipher.charAt(index++);
                }
            }
        }

        StringBuilder result = new StringBuilder();
        row = 0;
        col = 0;
        for (int i = 0; i < cipher.length(); i++) {
            if (row == 0) {
                down = true;
            }
            if (row == key - 1) {
                down = false;
            }
            if (rail[row][col] != '*') {
                result.append(rail[row][col++]);
            }
            row += down ? 1 : -1;
        }
        return result.toString();
    }
}